package com.gupao.mic.token.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * 腾讯课堂搜索 咕泡学院
 * 加群获取视频：608583947
 * 风骚的Michael 老师
 */
@Controller
public class ManagerController {

    @RequestMapping(value = "/mg/index",method = RequestMethod.GET)
    public String index(){
        return "controller";
    }


}
